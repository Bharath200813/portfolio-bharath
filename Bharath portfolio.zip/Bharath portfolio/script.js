// Select HTML elements
const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];

// Current year
$('#year').textContent = new Date().getFullYear();

// Scroll progress and back-to-top
function onScroll() {
    const max = document.documentElement.scrollHeight - innerHeight;

    $('#progress').style.width =
        (max > 0 ? scrollY / max * 100 : 0) + '%';

    $('#topbtn').classList.toggle('show', scrollY > 500);

    let current = 'home';

    $$('main section[id]').forEach(sec => {
        if (scrollY >= sec.offsetTop - 150) {
            current = sec.id;
        }
    });

    $$('.links a').forEach(a => {
        a.classList.toggle(
            'active',
            a.getAttribute('href') === '#' + current
        );
    });
}

addEventListener('scroll', onScroll, { passive: true });
onScroll();

$('#topbtn').onclick = () => {
    scrollTo({ top: 0, behavior: 'smooth' });
};

// Mobile menu
$('#menu').onclick = () => {
    $('#navlinks').classList.toggle('open');

    $('#menu').textContent =
        $('#navlinks').classList.contains('open') ? '✕' : '☰';
};

$$('.links a').forEach(a => {
    a.addEventListener('click', () => {
        $('#navlinks').classList.remove('open');
    });
});

// Theme toggle
const savedTheme = localStorage.getItem('bharath-theme');

if (savedTheme === 'light') {
    document.body.classList.add('light');
}

function themeIcon() {
    $('#theme').textContent =
        document.body.classList.contains('light') ? '☾' : '☼';
}

themeIcon();

$('#theme').onclick = () => {
    document.body.classList.toggle('light');

    localStorage.setItem(
        'bharath-theme',
        document.body.classList.contains('light') ? 'light' : 'dark'
    );

    themeIcon();

    $('#toast').classList.add('show');

    setTimeout(() => {
        $('#toast').classList.remove('show');
    }, 1300);
};

// Reveal animations
const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');

            $$('[data-width]', entry.target).forEach(bar => {
                bar.style.width = bar.dataset.width;
            });

            observer.unobserve(entry.target);
        }
    });
}, { threshold: 0.13 });

$$('.reveal').forEach((el, i) => {
    el.style.setProperty('--delay', (i % 4) * 85 + 'ms');
    el.classList.add('stagger');
    observer.observe(el);
});

// Skill bar animation
const barObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            $$('[data-width]', entry.target).forEach(bar => {
                bar.style.width = bar.dataset.width;
            });

            barObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.2 });

$$('.skill-card').forEach(el => barObserver.observe(el));

// Typewriter effect
const words = [
    'digital experiences',
    'responsive websites',
    'useful interfaces',
    'clean code'
];

let wi = 0;
let ci = 0;
let del = false;

function type() {
    const target = $('#typed');

    if (!target) return;

    const word = words[wi];
    target.textContent = word.slice(0, ci);

    if (!del && ci < word.length) {
        ci++;
    } else if (del && ci > 0) {
        ci--;
    } else if (!del) {
        del = true;
        setTimeout(type, 1100);
        return;
    } else {
        del = false;
        wi = (wi + 1) % words.length;
    }

    setTimeout(type, del ? 45 : 85);
}

type();

// 3D profile card animation
const visual = $('#visual');
const card = $('#profilecard');

if (matchMedia('(pointer:fine)').matches) {
    visual.addEventListener('mousemove', e => {
        const r = visual.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;

        card.style.transform =
            `rotateY(${x * 13 - 3}deg) rotateX(${-y * 10}deg) translateY(-3px)`;
    });

    visual.addEventListener('mouseleave', () => {
        card.style.transform = 'rotateY(-7deg) rotateX(3deg)';
    });
}

// Profile photo click animation
const photoStage = $('#photo-stage');

function sparkBurst(el) {
    const icons = ['✦', '✧', '✺', '＋', '•'];

    for (let i = 0; i < 12; i++) {
        const sp = document.createElement('span');

        sp.className = 'spark';
        sp.textContent = icons[i % icons.length];
        sp.style.left = '50%';
        sp.style.top = '50%';

        const angle = Math.PI * 2 * i / 12;
        const dist = 55 + Math.random() * 55;

        sp.style.setProperty('--sx', Math.cos(angle) * dist + 'px');
        sp.style.setProperty('--sy', Math.sin(angle) * dist + 'px');

        sp.style.color = i % 2 ? 'var(--accent2)' : 'var(--pink)';

        el.appendChild(sp);

        setTimeout(() => sp.remove(), 900);
    }
}

photoStage.addEventListener('click', () => {
    photoStage.classList.remove('photo-pop');
    void photoStage.offsetWidth;
    photoStage.classList.add('photo-pop');

    sparkBurst(photoStage);

    setTimeout(() => {
        photoStage.classList.remove('photo-pop');
    }, 600);
});

// Profile card glow animation
card.addEventListener('click', e => {
    if (e.target.closest('button') || e.target.closest('input')) return;

    card.classList.remove('photo-pop');
    void card.offsetWidth;
    card.classList.add('photo-pop');

    sparkBurst(card);

    setTimeout(() => {
        card.classList.remove('photo-pop');
    }, 600);
});

// Contact form
$('#contact-form').addEventListener('submit', e => {
    e.preventDefault();

    const name = $('#name').value.trim();
    const email = $('#email').value.trim();
    const subject = $('#subject').value.trim();
    const message = $('#message').value.trim();

    if (!name || !email || !subject || !message) {
        $('#form-status').textContent = 'Please complete every field.';
        return;
    }

    const body =
        `Hi Bharathkumar,\n\n${message}\n\nFrom: ${name}\nReply email: ${email}`;

    $('#form-status').textContent = 'Opening your email app…';

    location.href =
        `mailto:bharathkumar123123@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
});

// Magnetic button animation
if (matchMedia('(pointer:fine)').matches) {
    $$('.magnetic').forEach(el => {
        el.addEventListener('mousemove', e => {
            const r = el.getBoundingClientRect();

            el.style.transform =
                `translate(${(e.clientX - r.left - r.width / 2) * 0.08}px, ${(e.clientY - r.top - r.height / 2) * 0.12}px)`;
        });

        el.addEventListener('mouseleave', () => {
            el.style.transform = '';
        });
    });
}

// Project filters
const filterButtons = [
    ...document.querySelectorAll('.filter-btn')
];

filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        filterButtons.forEach(b => {
            b.classList.toggle('active', b === btn);
        });

        const filter = btn.dataset.filter;

        document.querySelectorAll('.project-card').forEach(card => {
            card.classList.toggle(
                'filtered-out',
                filter !== 'all' && card.dataset.category !== filter
            );
        });
    });
});

// Command search popup
const commandOverlay = $('#command-overlay');
const commandSearch = $('#command-search');
const commandResults = $('#command-results');

function openCommand() {
    commandOverlay.classList.add('open');
    commandOverlay.setAttribute('aria-hidden', 'false');

    setTimeout(() => commandSearch.focus(), 40);
}

function closeCommand() {
    commandOverlay.classList.remove('open');
    commandOverlay.setAttribute('aria-hidden', 'true');

    $('#command-launch').focus();
}

$('#command-launch').addEventListener('click', openCommand);

commandOverlay.addEventListener('click', e => {
    if (e.target === commandOverlay) {
        closeCommand();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        openCommand();
    }

    if (e.key === 'Escape' && commandOverlay.classList.contains('open')) {
        closeCommand();
    }
});

// Search navigation items
commandSearch.addEventListener('input', () => {
    const q = commandSearch.value.trim().toLowerCase();

    commandResults.querySelectorAll('button').forEach(btn => {
        btn.hidden = !btn.textContent.toLowerCase().includes(q);
    });
});

commandResults.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', () => {
        const target = btn.dataset.go;

        closeCommand();

        document.querySelector(target)?.scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Pointer spotlight and project card tilt
if (matchMedia('(pointer:fine)').matches) {
    document.addEventListener('pointermove', e => {
        document.documentElement.style.setProperty('--mx', e.clientX + 'px');
        document.documentElement.style.setProperty('--my', e.clientY + 'px');
    });

    document.querySelectorAll('.project-card').forEach(card => {
        card.addEventListener('pointermove', e => {
            const r = card.getBoundingClientRect();
            const x = (e.clientX - r.left) / r.width - 0.5;
            const y = (e.clientY - r.top) / r.height - 0.5;

            card.style.transform =
                `perspective(900px) rotateY(${x * 3}deg) rotateX(${-y * 2}deg) translateY(-5px)`;
        });

        card.addEventListener('pointerleave', () => {
            card.style.transform = '';
        });
    });
}

// Clickable details modal
(() => {
    const overlay = $('#detail-overlay');
    const title = $('#detail-title');
    const kicker = $('#detail-kicker');
    const content = $('#detail-content');
    const dialog = $('#detail-dialog');

    const closeBtn = $('#detail-close');
    const doneBtn = $('#detail-done');
    const exploreBtn = $('#detail-explore');

    let previousFocus = null;
    let currentSection = '#projects';

    const selectors =
        '.project-card,.service-card,.cred-card,.skill-card,.fact,.about-grid .panel,.interest-card';

    document.querySelectorAll(selectors).forEach(item => {
        item.classList.add('tap-ready');
        item.setAttribute('tabindex', '0');
        item.setAttribute('role', 'button');
        item.setAttribute('aria-haspopup', 'dialog');

        item.setAttribute(
            'aria-label',
            'Open details: ' +
            (item.querySelector('h3,h4,strong')?.textContent.trim() || 'Explore this item')
        );

        const open = () => {
            previousFocus = item;

            const heading = item.querySelector('h2,h3,h4,strong');

            title.textContent = heading
                ? heading.textContent.trim()
                : 'A little more to explore';

            const section = item.closest('section');

            currentSection = section ? '#' + section.id : '#projects';

            kicker.textContent =
                (section?.querySelector('.kicker')?.textContent.trim() || 'Portfolio').toUpperCase();

            const clone = item.cloneNode(true);

            clone.classList.remove('tap-ready', 'reveal', 'visible', 'stagger');
            clone.removeAttribute('tabindex');
            clone.removeAttribute('role');

            clone.querySelectorAll('button,input,textarea,form').forEach(el => {
                el.remove();
            });

            content.replaceChildren(clone);

            overlay.classList.add('open');
            overlay.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden';

            dialog.focus();
        };

        item.addEventListener('click', e => {
            if (e.target.closest('a,button,input,textarea,select,label')) return;
            open();
        });

        item.addEventListener('keydown', e => {
            if (
                (e.key === 'Enter' || e.key === ' ') &&
                !e.target.closest('a,button,input,textarea,select')
            ) {
                e.preventDefault();
                open();
            }
        });
    });

    function close() {
        overlay.classList.remove('open');
        overlay.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        content.replaceChildren();

        previousFocus?.focus?.();
    }

    closeBtn.addEventListener('click', close);
    doneBtn.addEventListener('click', close);

    overlay.addEventListener('click', e => {
        if (e.target === overlay) {
            close();
        }
    });

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape' && overlay.classList.contains('open')) {
            close();
        }
    });

    exploreBtn.addEventListener('click', () => {
        const target = document.querySelector(currentSection);

        close();

        target?.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    });
})();